﻿using System.Windows;

namespace DeliveryServiceManager
{
    public partial class App : Application
    {
        // Можно добавить глобальные настройки здесь
    }
}